﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Prueba
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private void BtnSeleccionMascota(object sender, RoutedEventArgs e)
        {
            String opciones = "";
            if (chbGato.IsChecked == true) {
                opciones += chbGato.Content + "\n";
            }
            if (chbAraña.IsChecked == true)
            {
                opciones += chbAraña.Content + "\n";
            }
            if (chbLoro.IsChecked == true)
            {
                opciones += chbLoro.Content + "\n";
            }
            if (chbPerro.IsChecked == true)
            {
                opciones += chbPerro.Content + "\n";
            }
            if (chbPez.IsChecked == true)
            {
                opciones += chbPez.Content + "\n";
            }
            if (chbHamster.IsChecked == true)
            {
                opciones += chbHamster.Content + "\n";
            }
            if(opciones.Length == 0)
            {
                opciones = "Ninguna opcion seleccionada";
            }
            MessageBox.Show(opciones, "Mascotas seleccionadas");

        }

        private void checkTodos(object sender, RoutedEventArgs e)
        {
            cambiaEstadoCheckBox(true);
        }
        private void uncheckTodos(object sender, RoutedEventArgs e)
        {
            cambiaEstadoCheckBox(false);
        }
        private void cambiaEstadoCheckBox(bool isSeleccionado)
        {
            chbGato.IsChecked = isSeleccionado;
            chbAraña.IsChecked = isSeleccionado;
            chbLoro.IsChecked = isSeleccionado;
            chbPerro.IsChecked = isSeleccionado;
            chbPez.IsChecked = isSeleccionado;
            chbHamster.IsChecked = isSeleccionado;
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void btn_generarClic(object sender, RoutedEventArgs e)
        {
            if(txt_opciones != null && txt_opciones.Text.Length > 0)
            {
                String[] separador = { ";", "," };
                String[] opciones = txt_opciones.Text.Split(separador, StringSplitOptions.RemoveEmptyEntries);
                wp_opciones.Children.Clear();
                foreach(string opcion in opciones){
                    CheckBox check = new CheckBox();
                    check.Content = opcion;
                    check.Margin = new Thickness(10);
                    wp_opciones.Children.Add(check);
                    Console.WriteLine(check.Content);
                }
                txt_opciones.Text = "";
            }
            else
            {
                MessageBox.Show("Para generar los componentes debes agregar por lo menos un valor", "Campos requeridos");
            }
        }
    }
}